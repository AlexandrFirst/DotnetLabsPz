﻿using Lost_And_Found_LIB;
using System;

namespace Test_PZ1
{
    class Program
    {
        static void Main(string[] args)
        {
            Office office = new Office();
        }
    }
}
